const { VoiceChannel } = require('discord.js');
const { log } = require('../../functions');

module.exports = {
    event: "channelUpdate",
    /**
     *
     * @param {ExtendedClient} client
     * @param {import('discord.js').Interaction} interaction
     * @returns
     */
    run: async (client, interaction) => {
        // later...
    }
}
